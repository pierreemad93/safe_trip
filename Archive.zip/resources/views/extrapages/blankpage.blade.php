<x-app-layout>
<div class="container-fluid">
         <div class="row">
            <div class="col-lg-12">
               Here Add Your HTML Content.....
            </div>
         </div>
      </div>
</x-app-layout>