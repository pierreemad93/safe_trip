<x-guest-layout>
<div class="mt-5 mm-maintenance">
            <div class="container-fluid p-0">
               <div class="row no-gutters">
                  <div class="col-sm-12 text-center">
                        <div class="mm-maintenance">
                           <img src={{URL::asset("images/error/maintenance.png")}} class="img-fluid" alt="">
                           <h3 class="mt-4 mb-2">Site Currently Under Maintenance</h3>
                           <p class="mb-2">Please check back in sometime.</p>
                           <p>Contact with <a href="#">dummy@example.com</a></p>
                        </div>
                  </div>
               </div>
            </div>
         </div>
</x-guest-layout>
